import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class FormulaireAchatCondiment extends Application {

    @Override
    public void start(Stage primaryStage) {
      
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.TOP_LEFT);
        grid.setHgap(10);
        grid.setVgap(5); 
        grid.setPadding(new Insets(25, 25, 25, 25));

        Text title = new Text("Sauvegarde de condiments");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        grid.add(title, 0, 0, 3, 1);


        Label nomLabel = new Label("Nom:");
        TextField nomField = new TextField();
        nomField.setPrefWidth(200);
        

        Label nomHelp = new Label("Veuillez saisir le nom");
        nomHelp.setFont(Font.font("Arial", FontWeight.NORMAL, 10));
        nomHelp.setTextFill(Color.GRAY);
        
        Label nomError = new Label();
        nomError.setTextFill(Color.RED);

        Label typeLabel = new Label("Type:");
        TextField typeField = new TextField();
        typeField.setPrefWidth(200);
        Label typeError = new Label();
        typeError.setTextFill(Color.RED);

        Label prixLabel = new Label("Prix:");
        TextField prixField = new TextField();
        prixField.setPrefWidth(200);
        Label prixError = new Label();
        prixError.setTextFill(Color.RED);

        Label quantiteLabel = new Label("Quantité:");
        TextField quantiteField = new TextField();
        quantiteField.setPrefWidth(200);
        Label quantiteError = new Label();
        quantiteError.setTextFill(Color.RED);

       
        grid.add(nomLabel, 0, 1);
        grid.add(nomField, 1, 1);
        grid.add(nomError, 2, 1);
        grid.add(nomHelp, 1, 2); 

        grid.add(typeLabel, 0, 3);
        grid.add(typeField, 1, 3);
        grid.add(typeError, 2, 3);

        grid.add(prixLabel, 0, 4);
        grid.add(prixField, 1, 4);
        grid.add(prixError, 2, 4);

        grid.add(quantiteLabel, 0, 5);
        grid.add(quantiteField, 1, 5);
        grid.add(quantiteError, 2, 5);

    
        Scene scene = new Scene(grid, 700, 500);
        
    
        primaryStage.setTitle("Sauvegarde de condiments");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}